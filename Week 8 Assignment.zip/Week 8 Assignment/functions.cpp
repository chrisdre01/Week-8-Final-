#include <iostream>
#include "functions.h"

// Function definition
void showData(const std::string data[], int size) {
    if (size == 0) {
        std::cout << "No data to display." << std::endl;
    } else {
        std::cout << "Displaying Data:\n";
        for (int i = 0; i < size; ++i) {
            std::cout << "Element " << i + 1 << ": " << data[i] << std::endl;
        }
    }
}
