#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <string>

// Function declaration
void showData(const std::string data[], int size);

#endif
