#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include <sstream>
#include <thread>
#include <uuid/uuid.h>
#include <vector>
#include "functions.h"


using namespace std;

class Session {
private:
    std::string sessionID;
    std::string username;
    time_t authenticationTime;
    time_t logoutTime;

public:
    // Constructor to initialize session
    Session(const std::string& username) : username(username) {
        // Generate unique session ID
        generateSessionID();

        // Set authentication time
        authenticationTime = std::time(nullptr);

        // Initialize logout time to 0 (not logged out yet)
        logoutTime = 0;
    }

    // Function to generate a unique session ID
    void generateSessionID() {
        uuid_t uid;
        uuid_generate(uid);

        char uuidStr[37];
        uuid_unparse(uid, uuidStr);

        sessionID = uuidStr;
    }

    // Function to get session ID
    std::string getSessionID() const {
        return sessionID;
    }

    // Function to get username
    std::string getUsername() const {
        return username;
    }

    // Function to get authentication time
    time_t getAuthenticationTime() const {
        return authenticationTime;
    }

    // Function to get logout time
    time_t getLogoutTime() const {
        return logoutTime;
    }

    // Function to set logout time
    void setLogoutTime() {
        // Set logout time to the current time
        logoutTime = std::time(nullptr);
    }

    // Function to display session information
    void displaySessionInfo() const {
        std::cout << "Session ID: " << sessionID << std::endl;
        std::cout << "Username: " << username << std::endl;
        std::cout << "Authentication Time: " << std::ctime(&authenticationTime);
        
        if (logoutTime != 0) {
            std::cout << "Logout Time: " << std::ctime(&logoutTime);
        } else {
            std::cout << "Not logged out yet." << std::endl;
        }
    }
};

int main() {
    // Example usage of Session class
    Session session("andre_johnson");

    // Simulate logout after some time
    std::cout << "Simulating logout after 10 seconds..." << std::endl;
    std::this_thread::sleep_for(std::chrono::seconds(10));
    session.setLogoutTime();

    // Display session information
    session.displaySessionInfo();

    return 0;
}

// Manager.h
#ifndef MANAGER_H
#define MANAGER_H 

// ...(Manager class definition)
class Manager {
private:
    double salary;
    std::string username;
    std::string password;

#endif // MANAGER_H

public:
  Manager(const Manager &) = default;
  Manager(Manager &&) = default;
  Manager &operator=(const Manager &) = default;
  Manager &operator=(Manager &&) = default;
  // Constructor to initialize the Manager object
  Manager(double initialSalary, const std::string &initialUsername,
          const std::string &initialPassword)
      : salary(initialSalary), username(initialUsername),
        password(initialPassword) {}

  // Getter functions to retrieve private members
  double getSalary() const { return salary; }

  std::string getUsername() const { return username; }

  // Note: It's not recommended to provide a getter for the password in a
  // real-world application. Passwords should be kept private and not exposed.

  // Setter function to update the salary
  void setSalary(double newSalary) { salary = newSalary; }

  // Function to display manager details
  void displayDetails() const {
        std::cout << "Manager Details:\n";
        std::cout << "Username: " << username << "\n";
        std::cout << "Salary: $" << salary << "\n";
        // Note: Do not display the password for security reasons
        std::cout << "Password: " << password << "\n";
   }

// Employee class
class Employee {
private:
    std::string name;
    int employeeId;

public:
    // Constructor
    Employee(const std::string& name, int employeeId) : name(name), employeeId(employeeId) {}

    // Function to display employee information
    void displayInfo() const {
        std::cout << "Employee ID: " << employeeId << ", Name: " << name << std::endl;
    }
};

#ifndef MANAGER_H
#define MANAGER_H

// Manager class (inherits from Employee)
class Manager : public Employee 
private:
    std::string department;

public:
    // Constructor
    Manager(const std::string& name, int employeeId, const std::string& department)
        : Employee(name, employeeId), department(department) {}

    // Function to display manager information (overrides base class function)
    void displayInfo() const override {
        Employee::displayInfo();
        std::cout << "Department: " << department << std::endl;
    }
#endif // MANAGER_H

#ifndef MANAGER_H
#define MANAGER_H

class Manager : public Employee 
public:
    Manager(const std::string& name, int id, const std::string& department)
        : Employee(name, id), department(department) {}

    void displayInfo() const override {
        Employee::displayInfo();
        std::cout << "Department: " << department << "\n";
    }

private:
    std::string department;

#endif // MANAGER_H



string id1[30], name[30], address[50], dob[30], mobile_no[30], doj[30], marstatus[30], workd[30], workl[40], ctc[30], socialins[30], email[30];
int total = 0;

void enter()
{
    // Enter function 
    const int MAX_EMPLOYEES = 100;

// Define arrays to store employee data
string name[MAX_EMPLOYEES];
string address[MAX_EMPLOYEES];
string dob[MAX_EMPLOYEES];
string marstatus[MAX_EMPLOYEES];
string id[MAX_EMPLOYEES];
string doj[MAX_EMPLOYEES];
string workd[MAX_EMPLOYEES];
string workl[MAX_EMPLOYEES];
string ctc[MAX_EMPLOYEES];
string socialins[MAX_EMPLOYEES];
string mobile_no[MAX_EMPLOYEES];
string email[MAX_EMPLOYEES];

int totalEmployees = 0;

void enter()
;{
    int numEmployees;

    cout << "How many employees' data do you want to enter? ";
    cin >> numEmployees;

    if (totalEmployees + numEmployees > MAX_EMPLOYEES)
    {
        cout << "Error: Not enough space for additional employees." << endl;
        return;
    }

    for (int i = totalEmployees; i < totalEmployees + numEmployees; ++i)
    {
        cout << "\nEnter the data of Employee " << i + 1 << endl << endl;

        cout << "** PERSONAL DETAILS **" << endl << endl;
        cout << "Enter Name: ";
        cin >> name[i];

        cout << "Enter Address: ";
        cin >> address[i];

        cout << "Enter Date of Birth: ";
        cin >> dob[i];

        cout << "Is Employee Married? ";
        cin >> marstatus[i];

        cout << "** WORK DETAILS **" << endl << endl;
        cout << "Enter Id: ";
        cin >> id[i];

        cout << "Enter Date of Joining: ";
        cin >> doj[i];

        cout << "Work Department: ";
        cin >> workd[i];

        cout << "Enter Work Location: ";
        cin >> workl[i];

        cout << "Enter CTC: ";
        cin >> ctc[i];

        cout << "Enter Social Insurance Id: ";
        cin >> socialins[i];

        cout << "** CONTACT DETAILS **" << endl << endl;
        cout << "Enter Mobile NO: ";
        cin >> mobile_no[i];

        cout << "Enter Email: ";
        cin >> email[i];
    }

    totalEmployees += numEmployees;
}

    // Enter function
    enter();

    // You can now access the entered data in the arrays (name, address, etc.)
}

bool isUsernameAvailable(const string& username) {
    ifstream userFile("users.txt");
    string existingUsername;

    while (userFile >> existingUsername) {
        if (existingUsername == username) {
            cout << "Username already exists. Please choose another one." << endl;
            userFile.close();
            return false;
        }
    }

    userFile.close();
    return true;
}

string getValidUsername() {
    string username;
    bool isValid = false;

    while (!isValid) {
        cout << "Enter username: ";
        getline(cin, username);

        if (username.length() < 1) {
            cout << "Username should have at least one character." << endl;
        } else {
            isValid = isUsernameAvailable(username);
        }
    }

    return username;
}

void userNameValidation()
{
    string newName, checkName;
    int MiniPass;
    bool if_ON = true;
    bool oo = true;

    // UserName Validation
    while (oo)
    {
        cout << "Enter New UserName: ";
        getline(cin, newName);
        MiniPass = newName.length();
        
        fstream yusers;
        yusers.open("Users.txt", ios::in);

        if (if_ON && MiniPass >= 1 && yusers.is_open())
        {
            string readd;
            while (getline(yusers, readd))
            {
                stringstream OnlyUsers(readd);
                OnlyUsers >> checkName;
                if (newName == checkName)
                {
                    cout << "\n*" << newName << "* UserName already exists. Try another one\n"
                         << endl;
                    if_ON = false;
                }
            }
            yusers.close();

            if (!if_ON)
            {
                if_ON = true;
            }
            else
            {
                oo = false;
            }
        }
    }

    
}

void show()
{

    // Show function declaration
    void showData(const std::string data[], int size);

    const int arraySize = 5;
    string dataArray[arraySize] = {"Item 1", "Item 2", "Item 3", "Item 4", "Item 5"};

    // Call the showData function to display the contents of dataArray
    showData(dataArray, arraySize);

    // Show function definition
    void showData(const std::string data[], int size);
    if ('size' == 0) {
        std::cout << "No data to display." << std::endl;
    } else {
        std::cout << "Displaying Data:\n";
        for (int i = 0; i < 'size'; ++i) {
            std::cout << "Element " << i + 1 << ": " << "data"[i] << std::endl;
        }
    }
}


void search()
{
    // Search function 

    if (total == 0)

    {

        cout << "No data is entered" << endl;
    }

    else
    {

        string idd;

        cout << "Enter the id of Employee you want to Search: " << endl;

        cin >> idd;

        for (int i = 0; i < total; i++)

        {

            if (idd == id1[i])

            {
                cout << "RESULT FOR EMPLOYEE ID: " << idd << endl;

                cout << "** PERSONAL DETAILS **" << endl
                     << endl;

                cout << "Full Name: " << name[i] << endl;
                cout << "Address: " << address[i] << endl;
                cout << "Date of Birth: " << dob[i] << endl;
                cout << "Maritual Status: " << marstatus[i] << endl
                     << endl;

                cout << "** WORK DETAILS **" << endl
                     << endl;

                cout << "Id: " << id1[i] << endl;
                cout << "Date of Joing: " << doj[i] << endl;
                cout << "Work Department: " << workd[i] << endl;
                cout << "Work Location: " << workl[i] << endl;
                cout << "CTC: " << ctc[i] << endl;
                cout << "Social Insurance: " << socialins[i] << endl
                     << endl;

                cout << "** CONTACT DETAILS **" << endl
                     << endl;
                cout << "Mobile NO: " << mobile_no[i] << endl;
                cout << "Email Id: " << email[i] << endl;
            }
        }
    }
}

void update()
{
    // Update function
    if (total == 0)

    {

        cout << "No data is entered" << endl;
    }

    else {

        string rollno;

        cout << "Enter the Id of Employee which you want to update" << endl;

        cin >> rollno;

        for (int i = 0; i < total; i++)

        {

            if (rollno == id1[i])

            {

            cout << "\nPrevious Data: " << endl << endl;

            cout << "Data of Employee " << i + 1 << endl;

            cout << "** PERSONAL DETAILS **" << endl;

            cout << "Full Name: " << name[i] << endl;
            cout << "Address: " << address[i] << endl;
            cout << "Date of Birth: " << dob[i] << endl;
            cout << "Maritual Status: " << marstatus[i] << endl << endl;

            cout << "** WORK DETAILS **" << endl << endl;

            cout << "Id: " << id1[i] << endl;
            cout << "Date of Joing: " << doj[i] << endl;
            cout << "Work Department: " << workd[i] << endl;
            cout << "Work Location: " << workl[i] << endl;
            cout << "CTC: " << ctc[i] << endl;
            cout << "Social Insurance: " << socialins[i] << endl << endl;

            cout << "** CONTACT DETAILS **" << endl << endl;
            cout << "Mobile NO: " << mobile_no[i] << endl;
            cout << "Email Id: " << email[i] << endl;
            cout << "\nEnter new data: " << endl << endl;
            cout << "** PERSONAL DETAILS **" << endl << endl;

            cout << "Enter Name: " << endl;

            cin >> name[i];

            cout << "Enter Address: " << endl;

            cin >> address[i];

            cout << "Enter Date of Birth: " << endl;

            cin >> dob[i];

            cout << "Is Employee Married?: " << endl;

            cin >> marstatus[i];

            cout << "** WORK DETAILS **" << endl << endl;

            cout << "Enter Id: " << endl;

            cin >> id1[i];

            cout << "Enter Date of Joing: " << endl;

            cin >> doj[i];

            cout << "Work Department: " << endl;

            cin >> workd[i];

            cout << "Enter Work Location: " << endl;

            cin >> workl[i];

            cout << "Enter CTC: " << endl;

            cin >> ctc[i];

            cout << "Enter Social Insurance Id: " << endl;

            cin >> socialins[i];

            cout << "** CONTACT DETAILS **" << endl << endl;

            cout << "Enter Mobile NO: " << endl;

            cin >> mobile_no[i];

            cout << "Enter Email: " << endl;

            cin >> email[i];
            }
        }
    }
}

void Delete()
{
    // Delete function 
    if (total == 0)
    {
        cout << "No data is entered yet" << endl;
    }

    else
    {
        int a;

        cout << "Are you Sure to Delete Data?" << endl;
        cout << "Press 1 to delete all record" << endl;

        cin >> a;

        if (a == 1)

        {

            total = 0;

            cout << "All record is deleted..!!" << endl;
        }
        else
        {
            cout << "Please Press 1 to Delete All Record" << endl;
        }
    }
}

int main3()

{

    int value, sample;

    cout << "ENTER 1: To Proceed.." << endl;
    cin >> sample;

    while (sample < 2) // always in Loop

    {
        cout << ">>>>>>>>  EMPLOYEE RECORD MANAGEMENT SYSTEM  <<<<<<<<" << endl;

        cout << "\nPRESS 1: To Enter data" << endl;

        cout << "-------------------------" << endl;

        cout << "PRESSS 2: To Show data" << endl;
        cout << "-------------------------" << endl;

        cout << "PRESSS 3: To Search data" << endl;
        cout << "-------------------------" << endl;

        cout << "PRESSS 4: To Update data" << endl;
        cout << "-------------------------" << endl;

        cout << "PRESSS 5: To Delete data" << endl;
        cout << "-------------------------" << endl;

        cout << "PRESSS 6: To Quit" << endl;
        cout << "-------------------------" << endl;

        cin >> value;

        switch (value)

        {

        case 1:
            enter();
            break;

        case 2:
            show();
            break;

        case 3:
            search();
            break;

        case 4:
            update();
            break;

        case 5:
            Delete();
            break;

        case 6:
            exit(0);
            break;

        default:
            cout << "Invalid input" << endl;
            break;
        }
        
    }
        return 0;
}


void login()
{
    // Login function

string UserName,Password;
string UseEnter,PassEnter;
bool On_Off = true;
bool Off = true;
int countt = 0;
int left = 3;

cout << "\n**** Login to your Account **** \n";
while(On_Off){
    //********************************************
    fstream user;
    user.open("users.txt", ios::in);
    if(countt < 3 && Off && user.is_open()){
        if(countt > 0){
        cout << "\nPassword or UserName are not correct!!" << endl;
        left--;
        cout << "You have *" << left << "* attempts left \n" << endl;
        }
        cout << "Enter UserName: ";
        getline(cin,UseEnter);
        cout << "Enter Password: ";
        getline(cin,PassEnter);
        countt++;
        string read;
        //====================================================*
        while(getline(user,read)){
            stringstream convertor(read);
            convertor >> UserName >> Password;
            if(UseEnter == UserName && PassEnter == Password){
                Off = false;}}
        //=====================================================*
            }
    else if(!Off){
        cout << "\n**** Welcome! ****\n\n";
        user.close();
        On_Off = false;
}
    else {
        cout << "\n**** try again later!! **** \n\n";
        user.close();
        On_Off = false;
    }
}
}

void registry()
{

    // Registry function
    string newName,checkName,newPass,confirmPass;

    cout << "\n**** Create New Account **** \n";
}

int main4()
{
    int value, sample;

    cout << "ENTER 1: To Proceed.." << endl;
    cin >> sample;

    while (sample < 2) // always in Loop
    {
        cout << ">>>>>>>>  EMPLOYEE RECORD MANAGEMENT SYSTEM  <<<<<<<<" << endl;

        cout << "\nPRESS 1: To Enter data" << endl;
        // ... rest of your main function code ...

        cin >> value;

        switch (value)
        {
        case 1:
            enter();
            break;
        case 2:
            show();
            break;
        case 3:
            search();
            break;
        case 4:
            update();
            break;
        case 5:
            Delete();
            break;
        case 6:
            exit(0);
            break;
        default:
            cout << "Invalid input" << endl;
            break;
        }
    }

    return 0;
}
};